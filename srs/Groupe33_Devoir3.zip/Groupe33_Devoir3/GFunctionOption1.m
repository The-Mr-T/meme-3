
function g=GFunctionOption1(q0 , w0)
g =[ 0 0 -9.8 q0(1) q0(2) q0(3) ];
end